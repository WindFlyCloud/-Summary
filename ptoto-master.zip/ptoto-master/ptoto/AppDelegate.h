//
//  AppDelegate.h
//  ptoto
//
//  Created by 黄振宇 on 15/12/1.
//  Copyright © 2015年 YunMei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

