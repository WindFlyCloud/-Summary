//
//  PhotoView.m
//  aaaaaaaaaaaaaa
//
//  Created by mac on 16/3/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "PhotoView.h"

@implementation PhotoView


- (void)layoutSubviews
{
    [super layoutSubviews];
    if (!_hasShowedFistView)
    {
        [self showFirstImage];
    }
    
}


- (void)showFirstImage
{
    UIView *sourceView = self.clickBtn;
    CGRect rect = [self.sourceView convertRect:sourceView.frame toView:self];
    
    UIImageView *tempView = [[UIImageView alloc] init];
    tempView.backgroundColor = [UIColor yellowColor];
    [self addSubview:tempView];
    tempView.frame = rect;
    
    CGRect targetTemp = CGRectMake(0, 0, CGRectGetWidth([[UIScreen mainScreen]bounds])
                                   , CGRectGetHeight([[UIScreen mainScreen]bounds]));
    
    [UIView animateWithDuration:0.3 animations:^{
        tempView.center = self.center;
        tempView.bounds = (CGRect){CGPointZero, targetTemp.size};
    } completion:^(BOOL finished) {

        _hasShowedFistView = YES;
        self.backgroundColor = tempView.backgroundColor;
        [tempView removeFromSuperview];
    }];
}

- (void)show
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    self.frame = window.bounds;
    [window addObserver:self forKeyPath:@"frame" options:0 context:nil];
    [window addSubview:self];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAction:)];
    [self addGestureRecognizer:tap];
}

- (void)topAction:(UITapGestureRecognizer *)recognizer
{
    

    
    UIView *sourceView = self.clickBtn;
    CGRect targetTemp = [self.sourceView convertRect:sourceView.frame toView:self];
    
    UIImageView *tempView = [[UIImageView alloc] init];
    tempView.backgroundColor = [UIColor yellowColor];
    tempView.clipsToBounds = YES;

    
    
    tempView.bounds = CGRectMake(0, 0, CGRectGetWidth([[UIScreen mainScreen]bounds]), CGRectGetHeight([[UIScreen mainScreen]bounds]));
    tempView.center = self.center;
    
    [self addSubview:tempView];
    

    
    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundColor = [UIColor clearColor];
        tempView.frame = targetTemp;
        

    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

@end
