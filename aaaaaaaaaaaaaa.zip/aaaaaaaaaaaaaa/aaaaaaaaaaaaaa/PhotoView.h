//
//  PhotoView.h
//  aaaaaaaaaaaaaa
//
//  Created by mac on 16/3/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoView : UIView
{
    BOOL _hasShowedFistView;
}
@property(nonatomic,strong)UIView *sourceView;
@property(nonatomic,strong)UIButton *clickBtn;

- (void)show;
@end
