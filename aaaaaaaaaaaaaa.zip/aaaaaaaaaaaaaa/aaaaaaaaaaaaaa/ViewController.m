//
//  ViewController.m
//  aaaaaaaaaaaaaa
//
//  Created by mac on 16/3/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ViewController.h"
#import "PhotoView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (int i = 0; i<4; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.backgroundColor = [UIColor redColor];
        CGFloat w = (CGRectGetWidth(self.view.frame)-9)/2;
        
        btn.frame = CGRectMake((w+3) * (i%2), (i/2)*(w+3), w, w);
        [self.view addSubview:btn];
        [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    
}

-(void)btnAction:(UIButton*)btn
{
    PhotoView *browser = [[PhotoView alloc] init];

    browser.clickBtn = btn;
    browser.sourceView = self.view;
    
    [browser show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
