# MLLabel
UILabel with TextKit. support for Link and custom Expression. (iOS 7+)

- Long-press handling for links

**My library does not seek any reward,
but if you use this library, tell me if you like. :)**

![MLLabel](https://raw.githubusercontent.com/molon/MLLabel/master/snapshot1.png)
![MLLabel](https://raw.githubusercontent.com/molon/MLLabel/master/snapshot2.png)