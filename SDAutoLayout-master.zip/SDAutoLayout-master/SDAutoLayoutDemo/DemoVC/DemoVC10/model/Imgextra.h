//
//  Imgextra.h
//  SDAutoLayoutDemo
//
//  Created by lixiya on 16/1/14.
//  Copyright © 2016年 lixiya. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Imgextra : NSObject
@property (nonatomic,copy) NSString *imgsrc;

@end
