//
//  ViewController.m
//  Photo
//
//  Created by FanLang on 16/3/21.
//  Copyright © 2016年 FanLang. All rights reserved.
//

#import "ViewController.h"
#import "UIImageView+WebCache.h"
#import "SDPhotoGroup.h"
#import "SDPhotoItem.h"

#define UIScreenWidth   [UIScreen mainScreen].bounds.size.width
#define UIScreenHeight  [UIScreen mainScreen].bounds.size.height

@interface ViewController ()
{
    NSArray * _srcStringArray;
}

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    
    _srcStringArray = @[@"http://ww4.sinaimg.cn/thumbnail/996e0d92jw1eoxm33bf5hj20br0bqjso.jpg",@"http://ww4.sinaimg.cn/thumbnail/996e0d92jw1eoxm33bf5hj20br0bqjso.jpg",@"http://ww4.sinaimg.cn/thumbnail/996e0d92jw1eoxm33bf5hj20br0bqjso.jpg",@"http://ww4.sinaimg.cn/thumbnail/996e0d92jw1eoxm33bf5hj20br0bqjso.jpg",@"http://ww4.sinaimg.cn/thumbnail/996e0d92jw1eoxm33bf5hj20br0bqjso.jpg"];
    
    [self creatUI];
    
    
}

- (void)creatUI
{

    
    SDPhotoGroup *photoGroup = [[SDPhotoGroup alloc] initWithFrame:CGRectMake(0, 64, UIScreenWidth, UIScreenHeight - 64)];
    
    NSMutableArray *temp = [NSMutableArray array];
    [_srcStringArray enumerateObjectsUsingBlock:^(NSString *src, NSUInteger idx, BOOL *stop) {
        SDPhotoItem *item = [[SDPhotoItem alloc] init];
        item.thumbnail_pic = src;
        [temp addObject:item];
    }];
    
    photoGroup.photoItemArray = [temp copy];
    [self.view addSubview:photoGroup];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
