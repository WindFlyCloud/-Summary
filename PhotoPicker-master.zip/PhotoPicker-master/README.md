简单的图片选择器
======================
可以无限制的添加图片
------------------
![image](https://github.com/codeXiaoQiang/PhotoPicker/blob/master/2.pic.png)


实现抖动删除
----------------
![image](https://github.com/codeXiaoQiang/PhotoPicker/blob/master/3.pic.png)

