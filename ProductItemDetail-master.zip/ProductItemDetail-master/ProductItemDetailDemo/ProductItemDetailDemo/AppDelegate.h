//
//  AppDelegate.h
//  ProductItemDetailDemo
//
//  Created by wanyakun on 16/1/19.
//  Copyright © 2016年 wanyakun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

