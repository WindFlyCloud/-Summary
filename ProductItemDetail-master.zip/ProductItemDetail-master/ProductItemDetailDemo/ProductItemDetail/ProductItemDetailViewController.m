//
//  ProductItemDetailViewController.m
//  UCaiYuan
//
//  Created by wanyakun on 16/1/19.
//  Copyright © 2016年 com.ucaiyuan. All rights reserved.
//

#import "ProductItemDetailViewController.h"
#import <MJRefresh/MJRefresh.h>

#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)

@interface ProductItemDetailViewController ()


@end

@implementation ProductItemDetailViewController

#pragma mark - life cycle
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.edgesForExtendedLayout = UIRectEdgeNone;
    //设置上拉下拉
    [self setRefreshHeaderFooter];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.scrollView.contentSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.height *2);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)handleMemoryWarning
{
    //IBOutlet属性和成员变量对象直接赋值为nil
    
}

- (void)viewDidUnload {
    [super viewDidUnload];
}

#pragma mark - Delegate
#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 30;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.clipsToBounds = YES;
    }
    cell.textLabel.text = [NSString stringWithFormat:@"第%li行", indexPath.row];
    
    return cell;
}

#pragma mark - UITableViewDelegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}

#pragma mark - private method
- (void)setRefreshHeaderFooter
{
    __weak typeof(self) weakSelf = self;
    MJRefreshBackNormalFooter *refreshFooter = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [weakSelf.scrollView scrollRectToVisible:CGRectMake(0, self.view.frame.size.height, SCREEN_WIDTH, self.view.frame.size.height) animated:YES];
        [weakSelf.tableView.mj_footer endRefreshing];
        [weakSelf.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://m.baidu.com"]]];
    }];
    [refreshFooter setTitle:@"上拉加载图文详情" forState:MJRefreshStateIdle];
    [refreshFooter setTitle:@"上拉加载图文详情" forState:MJRefreshStatePulling];
    [refreshFooter setTitle:@"上拉加载图文详情" forState:MJRefreshStateRefreshing];
    [refreshFooter setTitle:@"上拉加载图文详情" forState:MJRefreshStateWillRefresh];
    [refreshFooter setTitle:@"上拉加载图文详情" forState:MJRefreshStateNoMoreData];
    
    self.tableView.mj_footer = refreshFooter;
    
    MJRefreshNormalHeader *refreshHeader = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf.scrollView scrollRectToVisible:CGRectMake(0, 0, SCREEN_WIDTH, self.view.frame.size.height) animated:YES];
        [weakSelf.webView.scrollView.mj_header endRefreshing];
    }];
    [refreshHeader setTitle:@"下拉回到图文详情" forState:MJRefreshStateIdle];
    [refreshHeader setTitle:@"释放回到图文详情" forState:MJRefreshStatePulling];
    [refreshHeader setTitle:@"释放回到图文详情" forState:MJRefreshStateRefreshing];
    [refreshHeader setTitle:@"释放回到图文详情" forState:MJRefreshStateWillRefresh];
    [refreshHeader setTitle:@"下拉回到图文详情" forState:MJRefreshStateNoMoreData];
    
    self.webView.scrollView.mj_header = refreshHeader;
}

#pragma mark - getter setter


@end
