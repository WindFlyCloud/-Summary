//
//  ProductItemDetailViewController.h
//  UCaiYuan
//
//  Created by wanyakun on 16/1/19.
//  Copyright © 2016年 com.ucaiyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductItemDetailViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIWebView *webView;


@end
