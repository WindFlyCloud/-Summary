# ProductItemDetail
模仿京东商品详情，实现上拉加载商品详情，下拉返回商品详情。

代码中使用到MJRefresh作为上拉和下拉的控件。
