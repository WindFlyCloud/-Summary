//
//  JCViewController.h
//  JCSegmentBarController
//
//  Created by 李京城 on 15/5/22.
//  Copyright (c) 2015年 lijingcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCViewController : UITableViewController

@end
