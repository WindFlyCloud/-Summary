//
//  JCAppDelegate.h
//  JCSegmentBarController
//
//  Created by 李京城 on 04/23/2015.
//  Copyright (c) 2014 lijingcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
