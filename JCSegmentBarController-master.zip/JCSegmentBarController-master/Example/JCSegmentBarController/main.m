//
//  main.m
//  JCSegmentBarController
//
//  Created by lijingcheng on 04/23/2015.
//  Copyright (c) 2014 lijingcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JCAppDelegate class]));
    }
}
