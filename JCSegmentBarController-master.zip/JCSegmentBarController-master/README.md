# JCSegmentBarController

[![CI Status](http://img.shields.io/travis/lijingcheng/JCSegmentBarController.svg?style=flat)](https://travis-ci.org/lijingcheng/JCSegmentBarController)
[![Version](https://img.shields.io/cocoapods/v/JCSegmentBarController.svg?style=flat)](http://cocoapods.org/pods/JCSegmentBarController)
[![License](https://img.shields.io/cocoapods/l/JCSegmentBarController.svg?style=flat)](http://cocoapods.org/pods/JCSegmentBarController)
[![Platform](https://img.shields.io/cocoapods/p/JCSegmentBarController.svg?style=flat)](http://cocoapods.org/pods/JCSegmentBarController)

Simple to use and support horizontally-scrolling.

<img width="320" src="./ScreenShot.gif"> 

## Installation

pod "JCSegmentBarController"

## Usage

Refer to demo

## Author

[李京城](http://lijingcheng.github.io)

## License

MIT
