# QQSlideBar

最近看到一个swift版本的侧滑栏，跟上一个版本的QQ一样，然后没有找到oc的版本，所以在这里转成OC的并自己修改了一些。
swift链接 ：https://lvwenhan.com/ios/446.html


这里的类 要实现跳转到相应的类的话只需在 LeftViewController 里面的 didSelectRowAtIndex 方法里面相应的实现

剩下的自定义就简单了


