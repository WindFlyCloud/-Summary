//
//  ContactsController.m
//  SlideLikeQQ
//
//  Created by LingLi on 15/12/23.
//  Copyright © 2015年 hailong.xie. All rights reserved.
//

#import "ContactsController.h"

@implementation ContactsController


- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.title = @"联系人";
    self.view.backgroundColor = [UIColor lightGrayColor];
    
}

@end
