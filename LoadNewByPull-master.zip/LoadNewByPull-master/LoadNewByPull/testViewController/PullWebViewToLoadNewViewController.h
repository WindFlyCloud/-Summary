//
//  PullWebViewToLoadNewViewController.h
//  LoadNewByPull
//
//  Created by huway_iosdev on 16/1/21.
//  Copyright © 2016年 chend. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PullWebViewToLoadNewViewController : UIViewController

@end
