//
//  AppDelegate.h
//  LoadNewByPull
//
//  Created by huway_iosdev on 16/1/20.
//  Copyright © 2016年 chend. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

